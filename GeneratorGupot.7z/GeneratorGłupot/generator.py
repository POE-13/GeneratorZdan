imię = ['Filip', 'Zbynio', 'Bożenka']
czasownik = ['robi', 'pije', 'pisze']
rzeczownik = ['xD', 'krew', 'super-sok']
from random import randint
def wybierz(słowo):
    liczba_słów = len (słowo)
    wybrana_liczba = randint(0, liczba_słów - 1)
    wybrane_słowo = słowo[wybrana_liczba]
    return wybrane_słowo
print(wybierz(imię), wybierz(czasownik), wybierz(rzeczownik), end='.')
